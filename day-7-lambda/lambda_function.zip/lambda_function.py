import json
import boto3 

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    
    response = ec2.run_instances(
        ImageId='ami-0df8c184d5f6ae949',  
        InstanceType='t2.micro', 
        KeyName='Demo_vpc', 
        MinCount=1,
        MaxCount=1
    )